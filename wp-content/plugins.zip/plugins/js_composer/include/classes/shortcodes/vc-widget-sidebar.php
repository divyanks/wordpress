<?php

class WPBakeryShortCode_VC_Widget_sidebar extends WPBakeryShortCode {
}